1. ���� ���!!

call_my_queue.c
call_my_queue_2
==> ~/linux-3.14.63/

Makefile
==> ~/linux-3.14.63/kernel/

my_queue_syscall.c
my_queue_syscall.o
==> ~/linux-3.14.63/kernel/

syscall_64.tbl
==> ~/linux-3.14.63/arch/x86/syscalls/

syscalls.h
==> ~/linux-3.14.63/include/linux/

