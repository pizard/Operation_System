#include <linux/kernel.h>
#include <linux/linkage.h>

	int array[100];
	int head = 0;
	int tail = 0;

	asmlinkage long sys_choi_enqueue(int n){
		int check =0;
		int a =0;
		for (a = head; a < tail; a++){
			if(array[a] == n ) {
			check = 1;
			}
		}
		if(check == 0){
			array[tail] = n;
			tail++;
			printk("enqueue success: %d \n", n);
		}else if(check == 1){
			printk("queue overlap \n");
		}
		return 0;

	}

	asmlinkage long sys_choi_dequeue(void) {
		printk("dequeue success : %d \n", array[head]);
		head++;
		return 0;
	}
