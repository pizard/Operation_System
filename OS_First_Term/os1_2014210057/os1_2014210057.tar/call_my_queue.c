#include <stdio.h>

int main(){
	syscall(316,10);
	syscall(316,20);
	syscall(316,30);
	syscall(317);
	syscall(316,40);
	syscall(316,50);
	syscall(317);
	syscall(317);
	syscall(316,60);
	syscall(317);

	return 0;
}
